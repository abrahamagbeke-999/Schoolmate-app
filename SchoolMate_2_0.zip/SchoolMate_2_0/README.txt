SCHOOLMATE 2.0 — PHONE-ONLY STARTER

Included:
- Assignment tracker with due dates and overdue labels
- Weekly timetable
- Dark mode
- Export/restore backup
- Local browser storage (offline-first approach)

Open:
1. Extract this ZIP.
2. In Acode, open index.html from the extracted folder.
3. Preview it and test adding an assignment and a class.

Important:
- This is a web app, not an Android APK or a Play Store release.
- Data is stored locally in the browser; export backups regularly.
- Cloud backup, cross-device sync, push notifications, and Play Store packaging are not included yet.
- For reliable PWA installation and service-worker offline caching, the app needs to be hosted over HTTPS. We can do that in a later step.
